﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class flight
    {
        [Key]
        public int FlightId { get; set; }
        [Required]
        public string FlightNumber { get; set; }
        [Required]
        public string Destination { get; set; }
        [Required]
        public string Origin { get; set; }
        public DateTime DepartureTime { get; set; }
        public DateTime ArrivalTime { get; set; }
        public flight()
        {
            
        }
    }
}

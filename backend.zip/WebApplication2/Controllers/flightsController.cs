﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class flightsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public flightsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: flights
        public async Task<IActionResult> Index()
        {
              return _context.flight != null ? 
                          View(await _context.flight.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.flight'  is null.");
        }

        // GET: flights/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.flight == null)
            {
                return NotFound();
            }

            var flight = await _context.flight
                .FirstOrDefaultAsync(m => m.FlightId == id);
            if (flight == null)
            {
                return NotFound();
            }

            return View(flight);
        }

        // GET: flights/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: flights/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FlightId,FlightNumber,Destination,Origin,DepartureTime,ArrivalTime")] flight flight)
        {
            if (ModelState.IsValid)
            {
                _context.Add(flight);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(flight);
        }

        // GET: flights/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.flight == null)
            {
                return NotFound();
            }

            var flight = await _context.flight.FindAsync(id);
            if (flight == null)
            {
                return NotFound();
            }
            return View(flight);
        }

        // POST: flights/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("FlightId,FlightNumber,Destination,Origin,DepartureTime,ArrivalTime")] flight flight)
        {
            if (id != flight.FlightId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(flight);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!flightExists(flight.FlightId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(flight);
        }

        // GET: flights/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.flight == null)
            {
                return NotFound();
            }

            var flight = await _context.flight
                .FirstOrDefaultAsync(m => m.FlightId == id);
            if (flight == null)
            {
                return NotFound();
            }

            return View(flight);
        }

        // POST: flights/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.flight == null)
            {
                return Problem("Entity set 'ApplicationDbContext.flight'  is null.");
            }
            var flight = await _context.flight.FindAsync(id);
            if (flight != null)
            {
                _context.flight.Remove(flight);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool flightExists(int id)
        {
          return (_context.flight?.Any(e => e.FlightId == id)).GetValueOrDefault();
        }
    }
}
